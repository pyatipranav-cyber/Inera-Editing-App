// Inera Edit Flow — full media understanding pass (watch + listen):
// frames (faces, sharpness, exposure, motion, shake, scene cuts) + audio (speech activity, loudness)
// + speech-to-text (Whisper) + transcript understanding.
import { frameMetrics, estimateShift, histDist, classifyVideo } from './video-analyzer.js';
import { loadFaceDetector, detectFacesSync, toGray } from './face-detect.js';
import { drawUpright } from './media-source.js';
import { transcribe, speechFrames } from './asr.js';
import { understand } from './understand.js';
import { makeCanvas, clamp, checkAbort } from './utils.js';

export const AUDIO_HOP = 0.05;

export async function analyzeMedia(src, { asrModel = 'base', language, skipAsr = false, knownTranscript = null, onStage, onProgress, signal } = {}) {
  const duration = src.duration;
  // ---- 1. watch: sample frames ----
  onStage && onStage('analyze');
  const interval = clamp(duration / 600, 0.25, 3);
  const sw = 160, sh = Math.max(16, Math.round(160 * src.height / src.width));
  const c = makeCanvas(sw, sh);
  const ctx = c.getContext('2d', { willReadFrequently: true });
  const classify = await loadFaceDetector();
  const reader = src.createFrameReader();
  const samples = [];
  let prevGray = null;
  try {
    for (let t = 0; t < duration - 0.05; t += interval) {
      checkAbort(signal);
      let fr;
      try { fr = await reader.frameAt(t); } catch (e) { continue; }
      drawUpright(ctx, fr, src.rotation, sw, sh);
      const img = ctx.getImageData(0, 0, sw, sh);
      const m = frameMetrics(img, prevGray);
      m.t = t;
      m.faces = classify ? detectFacesSync(classify, toGray(img.data, sw, sh), sw, sh, 8) : [];
      m.face = m.faces.length ? m.faces.reduce((a, b) => (b.size > a.size ? b : a)) : null;
      m.diff = samples.length ? histDist(samples[samples.length - 1].hist, m.hist) : 0;
      m.shift = prevGray ? estimateShift(m.gray, prevGray, sw, sh) : [0, 0];
      prevGray = m.gray;
      delete m.hist0;
      samples.push(m);
      onProgress && onProgress(t / duration);
    }
  } finally { reader.close(); }
  for (const s of samples) { s.gray = null; } // free memory; hist/hash kept for selection
  // ---- 2. listen: decode audio ----
  checkAbort(signal);
  onStage && onStage('audio');
  let pcm16 = null, store = null;
  if (src.hasAudio) {
    try { ({ pcm16, store } = await src.decodeAudio({ signal, onProgress })); }
    catch (e) { if (e && e.name === 'AbortError') throw e; pcm16 = null; store = null; }
  }
  const audio = { hasAudio: false, speech: new Uint8Array(0), segments: [], speechRatio: 0, rms: new Float32Array(0), kind: 'none' };
  let vad = null;
  if (pcm16 && pcm16.length > 1600) {
    vad = speechFrames(pcm16);
    // 50 ms RMS for loudness / emphasis
    const hop = 800, n = Math.floor(pcm16.length / hop);
    const rms = new Float32Array(n); let peak = 0;
    for (let f = 0; f < n; f++) { let s = 0; for (let i = f * hop; i < (f + 1) * hop; i++) { const v = pcm16[i] / 32768; s += v * v; const a = Math.abs(v); if (a > peak) peak = a; } rms[f] = Math.sqrt(s / hop); }
    audio.rms = rms; audio.peak = peak; audio.hasAudio = peak > 0.003;
  }
  // ---- 3. speech to text ----
  let transcript = { language: null, segments: [] };
  if (knownTranscript) transcript = knownTranscript; // e.g. Avatar Studio: words are already known exactly
  else if (audio.hasAudio && !skipAsr) {
    checkAbort(signal);
    onStage && onStage('transcribe');
    let lastDl = 0;
    transcript = await transcribe(pcm16, { model: asrModel, language, signal, onProgress, onDownload: (m) => { const now = performance.now(); if (now - lastDl > 250 || m.phase === 'load') { lastDl = now; onStage && onStage('download', m); } } });
  }
  // speech map at 50 ms from word timings (more reliable than energy alone)
  if (audio.hasAudio) {
    const n = audio.rms.length; const sp = new Uint8Array(n);
    for (const seg of transcript.segments) for (const w of seg.words || []) {
      const a = Math.max(0, Math.floor((w.s - 0.05) / AUDIO_HOP)), b = Math.min(n, Math.ceil((w.e + 0.05) / AUDIO_HOP));
      for (let i = a; i < b; i++) sp[i] = 1;
    }
    let act = 0; for (let i = 0; i < n; i++) act += sp[i];
    audio.speech = sp;
    audio.speechRatio = act / Math.max(1, n);
    audio.segments = transcript.segments.map((s) => ({ s: s.start, e: s.end }));
    audio.kind = audio.segments.length ? 'speech' : 'ambience';
  }
  const story = await understand(transcript);
  const cls = classifyVideo(samples, audio, duration);
  if (transcript.segments.length && audio.speechRatio > 0.3 && cls.type !== 'talking-head' && cls.motion < 0.05 && cls.faceRatio > 0.25) { cls.type = 'talking-head'; cls.reasons.unshift('continuous speech with a person on camera'); }
  return { duration, width: src.width, height: src.height, rotation: src.rotation, samples, audio, vad, transcript, story, cls, store, pcm16 };
}
